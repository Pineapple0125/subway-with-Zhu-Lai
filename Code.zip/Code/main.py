import tkinter
from tkinter import *
from tkinter import messagebox
import ttkbootstrap
from PIL import Image, ImageTk
from make_adj import *
import less_exchange

'''所有站点的名称'''
STL = ['西塱', '坑口', '花地湾', '芳村', '黄沙', '长寿路', '陈家祠', '西门口', '公元前', '农讲所', '烈士陵园', '东山口', '杨箕', '体育西路', '体育中心', '广州东站',
       '嘉禾望岗', '黄边', '江夏', '萧岗', '白云文化广场', '白云公园', '飞翔公园', '三元里', '广州火车站', '越秀公园', '纪念堂', '海珠广场', '市二宫', '江南西', '昌岗',
       '江泰路', '东晓南', '南洲', '洛溪', '南浦', '会江', '石壁', '广州南站', '机场北', '机场南', '高增', '人和', '龙归', '白云大道北', '永泰', '同和',
       '京溪南方医院', '梅花园', '燕塘', '林和西', '珠江新城', '天河客运站', '五山', '华师', '岗顶', '石牌桥', '广州塔', '客村', '大塘', '沥滘', '厦滘', '大石',
       '汉溪长隆', '市桥', '番禺广场']

INF = 0x3f3f3f3f
'''窗口居中显示'''


def center_window(root, swidth, sheight):
    screenwidth = root.winfo_screenwidth()  # 获取显示屏宽度
    screenheight = root.winfo_screenheight()  # 获取显示屏高度
    size = '%dx%d+%d+%d' % (swidth, sheight, (screenwidth - swidth) / 2, (screenheight - sheight) / 2)  # 设置窗口居中参数
    root.geometry(size)  # 让窗口居中显示


'''主页面'''


def main_window():
    def button_func1():
        start = lf.get()  # 始发站
        destination = lf2.get()  # 终点站
        global route
        try:
            if start in a and destination in a:  # a是站点列表
                start = G.locateVex(start)
                ending = G.locateVex(destination)
                G.FindTheLeast(start, ending)
                messagebox.showinfo(title='Query success', message="Time consumption:" + str(
                    anser[start][ending]) + " minutes" + "\n" + "The fastest path is:" + route + destination)
                route = ""
            else:
                messagebox.showinfo(title='Query failed',
                                    message='the unreachability of the two sites,\nPlease check the stations again')
        except:
            messagebox.showinfo(title='Query failed',
                                message='the unreachability of the two sites,\nPlease check the stations again')

    def button_func2():
        P = []  # 多条可能的乘客路径拼图，待拼接
        start = lf.get()
        destination = lf2.get()
        try:
            if start == destination and start in STL and destination in STL:
                messagebox.showinfo(title="Query success",
                                    message="Times of transfering: 0 minute \n" + "You are at the terminal ")
                pass
            else:
                paths = less_exchange.connection(start, destination, P)
                messagebox.showinfo(title="Query success", message="the route is:" + paths)
        except:
            messagebox.showinfo(title="Query failed",
                                message="the unreachability of the two sites,\nplease check the stations again")

    class Graph:
        '''初始化一个图'''

        def __init__(self, n=0, e=0):
            self.list = ["a" * e]  # 点的集合
            self.edge = [[INF] * e]
            self.n = n  # 边数量
            self.e = e  # 点数量

        '''读取数据变成地铁邻接矩阵'''

        def CreateAdjGraph(self, n, e, a, b):  # a表示站点名称，b表示读取的邻接矩阵
            for i in range(e):  # 66
                for j in range(e):  # 66
                    if b[i][j] == 'INF':
                        b[i][j] = INF  # 将字符串INF替换为无穷大
            self.n = n
            self.e = e
            self.list = a  # 站点名称列表
            self.edge = b  # 邻接矩阵

        '''根据索引找到当前站点对应名称'''

        def locateVex(self, value):
            for i in range(self.e):  # 遍历点集合
                if value == self.list[i]:
                    return i
            return False  # 没找到

        '''弗洛伊德算法'''

        def Floyd(self):

            for i in range(self.e):  # e=66
                for j in range(self.e):  # e=66
                    anser[i][j] = self.edge[i][j]  # 处理后的邻接矩阵传递到anser(接下来传递到pare)
                    if anser[i][j] < INF and i != j:
                        pare[i][j] = i  # 两点间直接相连
                    else:
                        pare[i][j] = -1  # 两点间没有直接相连

            for k in range(self.e):  # 遍历站点列表的索引
                for i in range(self.e):
                    for j in range(self.e):
                        if anser[i][k] + anser[k][j] < anser[i][j]:  # 满足更短路径
                            anser[i][j] = anser[i][k] + anser[k][j]  # 路径更新
                            pare[i][j] = pare[k][j]  # 前驱顶点更新

        def output(self):
            for i in range(self.e):
                for j in range(self.e):
                    print(anser[i][j], end=" ")
                print("\n")

            print("\n")

            for i in range(self.e):
                for j in range(self.e):
                    print(pare[i][j], end=" ")
                print("\n")

        '''寻找最短路径并存储在route中的函数'''

        def FindTheLeast(self, s, e):  # s代表起点，e代表终点

            global route
            route = ""
            if pare[s][e] != -1:
                self.FindTheLeast(s, pare[s][e])
                route += str(self.list[pare[s][e]]) + "------>"

    a, b = GetData()
    route = ""
    anser = [[INF] * 66 for i in range(66)]  # 最短路径列表
    pare = [[INF] * 66 for i in range(66)]  # 前驱顶点列表
    G = Graph()
    G.CreateAdjGraph(66, 66, a, b)
    G.Floyd()
    '''主页面开始构建'''
    root = ttkbootstrap.Window(themename="yeti")
    root.title("Subway line inquiry system")
    center_window(root, 1400, 1000)
    '''开头标签'''
    lb1 = Label(root, text='Subway line inquiry system', fg="Blue", font=('华文新魏', 24))
    lb1.place(relx=(1 - 0.8) / 2, rely=0.005, relwidth=0.8, relheight=0.05)
    '''地铁示意图'''
    photo = Image.open('Line1-3.png')  # 1-3号线的地铁路线图
    photo_resized = photo.resize((800, 900))
    photo2 = ImageTk.PhotoImage(photo_resized)
    metro = Label(root, image=photo2)
    metro.place(relx=0, rely=0.05, relwidth=0.79, relheight=0.98)
    photo3 = Image.open(('小地铁.png'))
    photo4 = photo3.resize((50, 50))
    photo4 = ImageTk.PhotoImage(photo4)
    photo5 = Image.open(('小地铁2.png'))
    photo6 = photo5.resize((50, 50))
    photo6 = ImageTk.PhotoImage(photo6)
    '''出发站点'''
    metro2 = Label(root, image=photo4)  # 输入框
    metro2.place(relx=0.72, rely=0.3, relwidth=0.05, relheight=0.05)
    lf = ttkbootstrap.Entry(root, bootstyle="primary")
    lf.place(relx=0.77, rely=0.3, relwidth=0.2, relheight=0.05)
    '''到达站点'''
    metro3 = Label(root, image=photo6)  # 输入框
    metro3.place(relx=0.72, rely=0.4, relwidth=0.05, relheight=0.05)
    lf2 = ttkbootstrap.Entry(root, bootstyle="success")
    lf2.place(relx=0.77, rely=0.4, relwidth=0.2, relheight=0.05)
    '''提示框'''
    option_text = "Complete the input box \nto begin query"
    LF = Label(root, text=option_text, font=("华文新魏", 15), fg="green")
    LF.place(relx=0.68, rely=0.2, relheight=0.07, relwidth=0.32)
    '''查询最小换乘'''
    search2 = tkinter.Button(root, text="Search least transition path", font=('华文新魏', 12), command=button_func2)  # 查询按钮
    search2.place(relx=0.75, rely=0.6, relwidth=0.2, relheight=0.08)
    '''查询最短路径'''
    search2 = tkinter.Button(root, text="Search fastest path", font=('华文新魏', 12), command=button_func1)  # 查询按钮
    search2.place(relx=0.75, rely=0.5, relwidth=0.2, relheight=0.08)
    '''温馨提示'''
    T1 = Label(root, image=photo4)
    T1.place(relx=0.72, rely=0.05, relwidth=0.05, relheight=0.05)
    T2 = Label(root, image=photo6)
    T2.place(relx=0.72, rely=0.12, relwidth=0.05, relheight=0.05)
    T3 = Label(root, text="Start", font=("华文新魏", 15))  # 注释：Start出发站
    T3.place(relx=0.8, rely=0.05, relwidth=0.13, relheight=0.05)
    T4 = Label(root, text="Destination", font=("华文新魏", 15))  # 注释：Destination 到达站
    T4.place(relx=0.8, rely=0.12, relwidth=0.13, relheight=0.05)

    root.mainloop()


main_window()
