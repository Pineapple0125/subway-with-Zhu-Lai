#-*- coding : utf-8-*-
# coding:unicode_escape
import csv
'''数据预处理'''
def GetData():
    global a,b
    SL=[]
    adj=[]
    with open('subway3.csv', newline='', encoding='utf-8',errors="ignore") as csvfile:#读取表格
        rows = csv.reader(csvfile)
        for row in rows:#按行读取
            SL.append(row[0])
            row2=[]
            for i in row:
                if i in "0123456789":
                    row2.append(int(i))
                else:
                    row2.append(i)
            line=row2[1::]
            adj.append(line)
    Station_list=SL[1::]
    adjacent_matrix=adj[1::]
    return Station_list,adjacent_matrix#Station_list站点列表，adjacent_matrix邻接矩阵