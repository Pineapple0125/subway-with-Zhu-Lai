class Line(object):
    def __init__(self, name, data):
        self.name = name
        self.data = data #站点名表

line1 = Line("line1", "西塱 坑口 花地湾 芳村 黄沙 长寿路 陈家祠 西门口 公元前 农讲所 烈士陵园 东山口 杨箕 体育西路 体育中心 广州东站")
line2 = Line("line2", "嘉禾望岗 黄边 江夏 萧岗 白云文化广场 白云公园 飞翔公园 三元里 广州火车站 越秀公园 纪念堂 公元前 海珠广场 市二宫 江南西 昌岗 江泰路 东晓南 南洲 洛溪 南浦 会江 石壁 广州南站")
line3 = Line("line3", "天河客运站 五山 华师 岗顶 石牌桥 体育西路 珠江新城 广州塔 客村 大塘 沥滘 厦滘 大石 汉溪长隆 市桥 番禺广场")
line4 = Line("line4", "机场北 机场南 高增 人和 龙归 嘉禾望岗 白云大道北 永泰 同和 京溪南方医院 梅花园 燕塘 广州东站 林和西 体育西路")

group = [line1, line2, line3, line4]
exchange_station = []#换乘站列表
'''构造换乘站列表'''
def initialize():
    exchangeStation = []
    for i in group:
        for j in group:
            if i.data != j.data:
                for k in set(i.data.split()).intersection(set(j.data.split())):
                    if k not in exchangeStation:
                        exchangeStation.append(k)
    global exchange_station
    exchange_station = exchangeStation.copy()
    return exchangeStation

'''判断两站是否在同一条线上
在：return 地铁线的名字
不在：return False
'''
def sameLine(station1, station2):
    for i in group:
        if (station1 in i.data) and (station2 in i.data):
            return i
    return False


def short_exchange(start_station, end_station, paths, exchange_station):
    if start_station == end_station:
        print(end_station)
        return
    line = sameLine(start_station, end_station)
    if line is not False:  # 两个站点在同一条线上
        line = line.data.split()
        if line.index(start_station) < line.index(end_station):
            paths.append(line[line.index(start_station):line.index(end_station) + 1])#构造乘客路径
        else:
            paths.append(line[line.index(end_station):line.index(start_station) + 1][::-1])#构造乘客路径

    else:  # 两个站点不在一条线上
        same_line = []
        for g in exchange_station:  # 看看哪个换乘站点在这条线路上
            line = sameLine(g, start_station)#找到与出发站同线的换乘站
            if (line is not False) and (g != start_station):
                same_line.append([g, abs(line.data.split().index(g)-line.data.split().index(start_station))])#每一个元素：[换乘站（对象），换乘与初始站的距离]
        same_line.sort(key=lambda x: x[1], reverse=False)#按照距离长短，从小到大排序
        for intersect in same_line:
            middle_station = intersect[0]#选最近的站换乘
            line = sameLine(start_station, middle_station)#找回当前始发站与同地铁线换乘站的线
            if line and (middle_station != start_station):
                line = line.data.split()
                if line.index(start_station) < line.index(middle_station):
                    paths.append(line[line.index(start_station):line.index(middle_station) + 1])#构造乘客路径
                else:
                    paths.append(line[line.index(middle_station):line.index(start_station) + 1][::-1])#构造乘客路径
                try:
                    exchange_station.remove(middle_station)#乘客移动到换乘站，该换乘站作废
                except:
                    pass
                short_exchange(middle_station, end_station, paths, exchange_station)
        pass


def connection(start, end, paths):
    short_exchange(start, end, paths, initialize())
    plans = [] # 所有线路的存放处
    for i in paths:
        if i[0] == start: # 获取头元素为起点的路段
            if i not in plans: # 从所有路段中提出头元素为起点的路段
                plans.append(i)
                paths.remove(i)

    while paths:  # 通过while循环让各个路段首尾相连
        for i in plans:
            for j in paths:
                if i[-1] == j[0]:
                    if i + j not in plans: # 如果不存在则添加1
                        plans.append(i + j)
                    paths.remove(j)
    deletes = []
    for delete in plans:
        if delete[0] != start or delete[-1] != end:
            deletes.append(delete)  # 获取所有线路中 首尾元素不符合的路段

    for delete in deletes:
        plans.remove(delete) # 将首尾元素不符合的路段删除

    for i in plans:  # 去重
        for j in range(len(i) - 1):
            if i[j + 1] == i[j]:
                i[j] = ""

    for path in plans:
        lines = []
        for station in path:
            for line in group:
                if (station not in exchange_station and station != "") and (station in line.data) and (line.name not in lines or len(lines) == 0):
                    lines.append(line.name)
        path.append(len(lines))

        pass

    # 从短到长排序
    plans.sort(key=lambda i: (i[-1], len(i)), reverse=False)

    # 输出最终线路
    result = ""
    plans[0].pop()
    for i in plans[0]:
        if i != "":
            if i != end:
                result += i + "------>"
            else:
                result += i
    return result


