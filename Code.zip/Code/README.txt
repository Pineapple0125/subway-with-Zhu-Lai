 You can run the main function is in 【main.py】
the data can be seen in 【subway3.csv】
the tests result can be seen in 【Tests.xlsx】
